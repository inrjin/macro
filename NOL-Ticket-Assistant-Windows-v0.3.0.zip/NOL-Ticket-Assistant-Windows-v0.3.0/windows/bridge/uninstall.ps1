param([ValidateSet('Chrome', 'Edge', 'Both')][string]$Browser = 'Both')
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$HostName = 'com.nol_ticket_assistant.bridge'
foreach ($Name in @('Chrome', 'Edge')) {
    if ($Browser -ne 'Both' -and $Browser -ne $Name) { continue }
    if ($Name -eq 'Chrome') { $RegistryPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName" }
    else { $RegistryPath = "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$HostName" }
    $ExpectedManifest = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot ('host.' + $Name.ToLowerInvariant() + '.json')))
    if (-not (Test-Path -LiteralPath $RegistryPath)) { Write-Host "$Name is not registered."; continue }
    $Registered = (Get-Item -LiteralPath $RegistryPath).GetValue('')
    if ($Registered -isnot [string] -or -not [string]::Equals($Registered, $ExpectedManifest, [StringComparison]::OrdinalIgnoreCase)) {
        Write-Warning "$Name points to another installation; leaving that registration unchanged."
        continue
    }
    # The host key is ours. Leave any unexpected additional values/subkeys alone.
    $Key = Get-Item -LiteralPath $RegistryPath
    $Key.DeleteValue('', $false)
    if ($Key.GetValueNames().Count -eq 0 -and $Key.GetSubKeyNames().Count -eq 0) { Remove-Item -LiteralPath $RegistryPath }
    Write-Host "Removed this installation's $Name registration."
}
Write-Host 'Program files and backups were kept. Previous registrations are not restored automatically.'
