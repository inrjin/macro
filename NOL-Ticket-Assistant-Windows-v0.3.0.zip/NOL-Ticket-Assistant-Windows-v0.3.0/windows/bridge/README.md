# Windows 브라우저 ↔ 매크로 연결

Chrome/Edge 확장 프로그램이 현재 활성 브라우저 창에서 실행 중인 `EnhancedMacro.ahk`에 시작 신호를 전달하는 작은 네이티브 호스트입니다. 브라우저에서 받은 명령으로 프로그램 실행, 파일 저장, 셸 실행을 하지 않습니다. 지원 요청은 `ping`과 `start` 두 가지입니다.

## 설치

1. 프로젝트 폴더를 Windows의 유지할 위치에 압축 해제합니다. 설치 후 이 폴더를 옮기면 다시 설치해야 합니다.
2. Chrome의 `chrome://extensions` 또는 Edge의 `edge://extensions`에서 개발자 모드를 켜고 확장 프로그램 폴더를 압축 해제된 확장 프로그램으로 로드합니다.
3. 확장 프로그램 ID 32자리를 복사합니다.
4. 이 `bridge` 폴더에서 명령 프롬프트를 열고 아래 명령의 ID를 실제 값으로 바꾸어 실행합니다.

```bat
install.cmd -Browser Chrome -ExtensionId abcdefghijklmnopabcdefghijklmnop
```

Edge는 `-Browser Edge`를 사용합니다. 두 브라우저에 설치하려면 각 ID를 따로 지정할 수 있습니다.

```bat
install.cmd -Browser Both -ChromeExtensionId abcdefghijklmnopabcdefghijklmnop -EdgeExtensionId ponmlkjihgfedcbaponmlkjihgfedcba
```

현재 사용자(HKCU)에만 등록하므로 관리자 권한은 필요하지 않습니다. Windows에 포함된 .NET Framework 4.x C# 컴파일러로 소스를 빌드하며 인터넷 다운로드는 없습니다. 기존 실행 파일, 매니페스트, 레지스트리 기본값은 `backups`에 보관합니다. 빌드 실패 시 브라우저 등록은 변경하지 않습니다.

`install.cmd`와 `uninstall.cmd`는 해당 PowerShell 프로세스에만 `ExecutionPolicy Bypass`를 지정합니다. 컴퓨터의 실행 정책은 변경하지 않습니다. 조직 정책으로 차단되어 있으면 설치가 실패할 수 있습니다. 원하면 스크립트를 확인한 뒤 허용된 PowerShell 환경에서 직접 `.\install.ps1`을 실행해도 됩니다.

## 확인

설치 후 PowerShell에서 다음 명령을 실행하면 매크로 시작/클릭 없이 메시지 형식과 잘못된 요청 거부를 확인합니다.

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\test.ps1
```

그다음 `EnhancedMacro.ahk`를 실행하고 브라우저 자동 시작을 허용합니다. 확장 프로그램의 연결 확인에서 네이티브 호스트와 매크로 실행 여부를 확인합니다. 처음에는 실제 예매 페이지 대신 제공된 테스트 페이지에서 동작을 확인하세요.

현재 제작 환경은 macOS이므로 Windows에서 C# 컴파일, 레지스트리 설치 및 AHK 메시지 수신의 실제 실행은 별도 확인이 필요합니다. `test.ps1`은 Windows에서 실행할 검증 도구이며, Windows에서 이미 통과했다고 의미하지 않습니다.

## 동작 계약

- 호스트 이름: `com.nol_ticket_assistant.bridge`
- 프레이밍: 4바이트 리틀엔디언 길이 + UTF-8 JSON, 최대 65,536바이트
- 연결 확인: `{"op":"ping"}` → `{"ok":true,"version":1,"macroRunning":true}`. `macroRunning`은 수신 창 존재 여부이며 자동 시작 허용 여부까지 보장하지 않습니다.
- 시작: `{"op":"start","browser":"chrome","requestId":"고유한-요청-ID"}`. Edge는 `msedge`입니다.
- 성공: `{"ok":true,"accepted":true}`. 시작 예약이 수락되었다는 뜻이며 좌석 선택 성공을 뜻하지 않습니다.
- 실패: `{"ok":false,"error":"오류코드","detail":"설명"}`.

호스트는 전경 창의 프로세스 실행 파일이 `chrome.exe` 또는 `msedge.exe`인지 확인합니다. 숨겨진 창 제목이 정확히 `NOL Ticket Assistant Bridge`인 수신자에게 `RegisterWindowMessage("NOLTicketAssistant.Start.v1")` 메시지를 전달합니다. `wParam=0`, `lParam=전경 브라우저 HWND`이며, AHK는 같은 창인지와 자동 시작 허용 여부를 확인한 뒤 비동기로 작업을 예약하고 `1`을 반환해야 합니다. 거부 시 `0`을 반환합니다.

응답 제한은 1.5초입니다. `macro_no_ack`는 전달 자체가 실패했거나 응답이 늦었다는 뜻으로, 실행 여부가 불확실하므로 자동 재시도하면 안 됩니다. `requestId` 중복 거부는 동일 호스트 프로세스 안에서만 유지됩니다. Chrome의 `sendNativeMessage`가 호출마다 새 프로세스를 만들 수 있으므로 확장 프로그램에서 탭/실행별 한 번만 전송하도록 보장해야 합니다. AHK도 실행 중 재시작을 거부해야 합니다.

확장 프로그램은 좌석 페이지 준비가 확인된 뒤 전송해야 합니다. 이 호스트는 브라우저 창의 HWND만 확인하며 URL, 활성 탭, 좌석 페이지 준비 상태를 읽지 않습니다. 시작 전 페이지 확인과 실행 중 창 변경 시 중지는 확장 프로그램과 AHK의 책임입니다.

## 제거

```bat
uninstall.cmd -Browser Both
```

이 폴더의 매니페스트를 가리키는 등록만 제거합니다. 다른 설치본을 가리키면 그대로 둡니다. 소스, 실행 파일, 백업은 남겨 두며 이전 설치의 등록을 자동 복구하지 않습니다. 복구가 필요하면 `backups`의 `registration-before.json`과 해당 파일을 확인하세요.
