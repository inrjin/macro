// .NET Framework 4.x; no NuGet dependencies. stdout is native messaging only.
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Web.Script.Serialization;

internal static class NativeHost
{
    private const int MaxMessageBytes = 65536;
    private const string BridgeTitle = "NOL Ticket Assistant Bridge";
    private const string StartMessage = "NOLTicketAssistant.Start.v1";
    private const uint ProcessQueryLimitedInformation = 0x1000;
    private const uint SmtoBlock = 0x0001;
    private const uint SmtoAbortIfHung = 0x0002;
    private static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = MaxMessageBytes, RecursionLimit = 8 };
    private static readonly HashSet<string> SeenRequests = new HashSet<string>(StringComparer.Ordinal);

    [DllImport("user32.dll")] private static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll", SetLastError = true)] private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern IntPtr FindWindow(string className, string windowName);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern uint RegisterWindowMessage(string name);
    [DllImport("user32.dll", SetLastError = true)] private static extern IntPtr SendMessageTimeout(IntPtr hwnd, uint message, UIntPtr wParam, IntPtr lParam, uint flags, uint timeout, out UIntPtr result);
    [DllImport("kernel32.dll", SetLastError = true)] private static extern IntPtr OpenProcess(uint access, bool inheritHandle, uint pid);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern bool QueryFullProcessImageName(IntPtr process, uint flags, StringBuilder name, ref uint size);
    [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr handle);

    public static int Main()
    {
        // A native host launched by Chrome/Edge must keep stdout free of logging.
        Stream input = Console.OpenStandardInput();
        Stream output = Console.OpenStandardOutput();
        try
        {
            while (true)
            {
                byte[] header = new byte[4];
                int first = input.ReadByte();
                if (first < 0) return 0;
                header[0] = (byte)first;
                ReadExactly(input, header, 1, 3);
                uint length = (uint)(header[0] | (header[1] << 8) | (header[2] << 16) | (header[3] << 24));
                if (length == 0 || length > MaxMessageBytes)
                {
                    Write(output, Failure("invalid_frame", "Message size must be 1..65536 bytes."));
                    return 1;
                }
                byte[] payload = new byte[(int)length];
                ReadExactly(input, payload, 0, payload.Length);
                Dictionary<string, object> reply;
                try
                {
                    var message = Json.DeserializeObject(new UTF8Encoding(false, true).GetString(payload)) as Dictionary<string, object>;
                    reply = message == null ? Failure("invalid_message", "Expected a JSON object.") : Handle(message);
                }
                catch (ArgumentException) { reply = Failure("invalid_message", "Invalid JSON or UTF-8 message."); }
                catch (InvalidOperationException) { reply = Failure("invalid_message", "Invalid JSON message."); }
                catch (Exception) { reply = Failure("host_error", "The native host could not process the request."); }
                Write(output, reply);
            }
        }
        catch (EndOfStreamException) { return 1; }
        catch (IOException) { return 1; }
    }

    private static Dictionary<string, object> Handle(Dictionary<string, object> message)
    {
        string op = StringField(message, "op");
        if (op != "ping" && op != "start") return Failure("unsupported_operation", "Only ping and start are supported.");
        foreach (string key in message.Keys)
            if (key != "op" && key != "browser" && key != "requestId") return Failure("invalid_message", "Unexpected message field.");

        IntPtr receiver = FindWindow(null, BridgeTitle);
        if (op == "ping")
            return new Dictionary<string, object> { { "ok", true }, { "version", 1 }, { "macroRunning", receiver != IntPtr.Zero } };

        string browser = StringField(message, "browser");
        if (browser != "chrome" && browser != "msedge") return Failure("invalid_browser", "browser must be chrome or msedge.");
        string requestId = StringField(message, "requestId");
        if (message.ContainsKey("requestId") && (requestId == null || requestId.Length == 0 || requestId.Length > 128))
            return Failure("invalid_request_id", "requestId must contain 1..128 characters.");
        if (requestId != null && !SeenRequests.Add(requestId)) return Failure("duplicate_request", "This host process already handled requestId.");
        if (receiver == IntPtr.Zero) return Failure("macro_not_running", "Start EnhancedMacro.ahk and enable browser-triggered start.");

        IntPtr foreground = GetForegroundWindow();
        if (foreground == IntPtr.Zero || !IsBrowser(foreground, browser + ".exe"))
            return Failure("wrong_foreground", "The selected browser must be the foreground window.");
        uint messageId = RegisterWindowMessage(StartMessage);
        if (messageId == 0) return Failure("message_registration_failed", "Windows could not register the start message.");
        // Close the small check/send race. The receiver checks this HWND again.
        if (GetForegroundWindow() != foreground) return Failure("foreground_changed", "The foreground window changed. Arm again after returning to the browser.");

        UIntPtr result;
        IntPtr delivered = SendMessageTimeout(receiver, messageId, UIntPtr.Zero, foreground, SmtoBlock | SmtoAbortIfHung, 1500, out result);
        if (delivered == IntPtr.Zero) return Failure("macro_no_ack", "The macro did not acknowledge the request; do not automatically retry.");
        if (result.ToUInt64() != 1) return Failure("macro_refused", "The macro refused the start. Check opt-in, target window, and configuration.");
        return new Dictionary<string, object> { { "ok", true }, { "accepted", true } };
    }

    private static bool IsBrowser(IntPtr hwnd, string expectedFileName)
    {
        uint pid;
        if (GetWindowThreadProcessId(hwnd, out pid) == 0 || pid == 0) return false;
        IntPtr process = OpenProcess(ProcessQueryLimitedInformation, false, pid);
        if (process == IntPtr.Zero) return false;
        try
        {
            uint size = 32768;
            var path = new StringBuilder((int)size);
            return QueryFullProcessImageName(process, 0, path, ref size)
                && string.Equals(Path.GetFileName(path.ToString()), expectedFileName, StringComparison.OrdinalIgnoreCase);
        }
        finally { CloseHandle(process); }
    }

    private static string StringField(Dictionary<string, object> message, string key)
    {
        object value;
        return message.TryGetValue(key, out value) ? value as string : null;
    }

    private static Dictionary<string, object> Failure(string error, string detail)
    {
        return new Dictionary<string, object> { { "ok", false }, { "error", error }, { "detail", detail } };
    }

    private static void ReadExactly(Stream stream, byte[] buffer, int offset, int count)
    {
        while (count > 0)
        {
            int read = stream.Read(buffer, offset, count);
            if (read == 0) throw new EndOfStreamException();
            offset += read;
            count -= read;
        }
    }

    private static void Write(Stream stream, Dictionary<string, object> value)
    {
        byte[] payload = Encoding.UTF8.GetBytes(Json.Serialize(value));
        int length = payload.Length;
        byte[] header = { (byte)length, (byte)(length >> 8), (byte)(length >> 16), (byte)(length >> 24) };
        stream.Write(header, 0, header.Length);
        stream.Write(payload, 0, payload.Length);
        stream.Flush();
    }
}
