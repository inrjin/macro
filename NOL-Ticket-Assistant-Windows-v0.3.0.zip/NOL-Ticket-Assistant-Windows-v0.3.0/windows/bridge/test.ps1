# Local protocol smoke test. Does not send a macro start request or click anything.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$Executable = Join-Path $PSScriptRoot 'NolTicketNativeHost.exe'
if (-not (Test-Path -LiteralPath $Executable -PathType Leaf)) { throw 'Run install.cmd first to compile the host.' }

function Invoke-Frame([string]$JsonText) {
    $Info = New-Object Diagnostics.ProcessStartInfo
    $Info.FileName = $Executable
    $Info.UseShellExecute = $false
    $Info.CreateNoWindow = $true
    $Info.RedirectStandardInput = $true
    $Info.RedirectStandardOutput = $true
    $Info.RedirectStandardError = $true
    $Process = New-Object Diagnostics.Process
    $Process.StartInfo = $Info
    try {
        [void]$Process.Start()
        $Body = [Text.Encoding]::UTF8.GetBytes($JsonText)
        $Size = [BitConverter]::GetBytes([uint32]$Body.Length)
        $Process.StandardInput.BaseStream.Write($Size, 0, 4)
        $Process.StandardInput.BaseStream.Write($Body, 0, $Body.Length)
        $Process.StandardInput.BaseStream.Flush()
        $Process.StandardInput.Close()
        if (-not $Process.WaitForExit(5000)) { $Process.Kill(); throw 'Native host timed out.' }
        $Output = New-Object IO.MemoryStream
        $Process.StandardOutput.BaseStream.CopyTo($Output)
        $Data = $Output.ToArray()
        if ($Data.Length -lt 4) { throw 'Native host returned no frame.' }
        $Length = [BitConverter]::ToUInt32($Data, 0)
        if ($Data.Length -ne $Length + 4) { throw 'Native host returned an invalid frame length.' }
        return ([Text.Encoding]::UTF8.GetString($Data, 4, $Length) | ConvertFrom-Json)
    }
    finally { $Process.Dispose() }
}

$Ping = Invoke-Frame '{"op":"ping"}'
if ($Ping.ok -ne $true -or $Ping.version -ne 1) { throw 'Ping failed.' }
Write-Host ('PASS ping; macroRunning=' + $Ping.macroRunning)
$Unknown = Invoke-Frame '{"op":"run","command":"calc.exe"}'
if ($Unknown.ok -ne $false -or $Unknown.error -ne 'unsupported_operation') { throw 'Unknown operation was not rejected.' }
Write-Host 'PASS unsupported operation rejected'
$Fields = Invoke-Frame '{"op":"ping","command":"calc.exe"}'
if ($Fields.ok -ne $false -or $Fields.error -ne 'invalid_message') { throw 'Unknown field was not rejected.' }
Write-Host 'PASS unknown fields rejected'
$Broken = Invoke-Frame '{broken'
if ($Broken.ok -ne $false -or $Broken.error -ne 'invalid_message') { throw 'Invalid JSON was not rejected.' }
Write-Host 'PASS invalid JSON rejected'
$Browser = Invoke-Frame '{"op":"start","browser":"firefox"}'
if ($Browser.ok -ne $false -or $Browser.error -ne 'invalid_browser') { throw 'Invalid browser was not rejected.' }
Write-Host 'PASS unsupported browser rejected (no start message sent)'
Write-Host 'All protocol smoke tests passed. Windows UI start still needs the separate manual dry run.'
