param(
    [ValidateSet('Chrome', 'Edge', 'Both')][string]$Browser = 'Chrome',
    [string]$ExtensionId = '',
    [string]$ChromeExtensionId = '',
    [string]$EdgeExtensionId = ''
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$HostName = 'com.nol_ticket_assistant.bridge'
$BridgeRoot = [IO.Path]::GetFullPath($PSScriptRoot)
$HostExe = Join-Path $BridgeRoot 'NolTicketNativeHost.exe'
$SourceFile = Join-Path $BridgeRoot 'NativeHost.cs'
$Utf8NoBom = New-Object Text.UTF8Encoding($false)

function Get-Target([string]$Name, [string]$Id) {
    if ($Id -cnotmatch '^[a-p]{32}$') { throw "$Name extension ID must contain exactly 32 lowercase letters a-p. Copy it from the browser extensions page." }
    if ($Name -eq 'Chrome') { $RegistryPath = "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName" }
    else { $RegistryPath = "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$HostName" }
    return [pscustomobject]@{
        Browser = $Name
        Id = $Id
        RegistryPath = $RegistryPath
        ManifestPath = (Join-Path $BridgeRoot ('host.' + $Name.ToLowerInvariant() + '.json'))
    }
}

if (-not $ChromeExtensionId) { $ChromeExtensionId = $ExtensionId }
if (-not $EdgeExtensionId) { $EdgeExtensionId = $ExtensionId }
$Targets = @()
if ($Browser -eq 'Chrome' -or $Browser -eq 'Both') { $Targets += Get-Target 'Chrome' $ChromeExtensionId }
if ($Browser -eq 'Edge' -or $Browser -eq 'Both') { $Targets += Get-Target 'Edge' $EdgeExtensionId }
if (-not (Test-Path -LiteralPath $SourceFile -PathType Leaf)) { throw "Missing source file: $SourceFile" }

$Compiler = $null
foreach ($RelativeCompiler in @('Microsoft.NET\Framework64\v4.0.30319\csc.exe', 'Microsoft.NET\Framework\v4.0.30319\csc.exe')) {
    $Candidate = Join-Path $env:WINDIR $RelativeCompiler
    if (Test-Path -LiteralPath $Candidate -PathType Leaf) { $Compiler = $Candidate; break }
}
if (-not $Compiler) { throw 'The Windows .NET Framework 4.x C# compiler was not found. This installer downloads nothing. Install/enable .NET Framework 4.x, then retry.' }

# Compile first: no registration changes if compilation fails.
$BuildExe = Join-Path $BridgeRoot ('NolTicketNativeHost.build.' + $PID + '.exe')
& $Compiler /nologo /target:exe /platform:anycpu /optimize+ /reference:System.Web.Extensions.dll ("/out:$BuildExe") $SourceFile
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $BuildExe)) { throw 'Compilation failed; browser registration was not changed.' }

$BackupDir = Join-Path $BridgeRoot ('backups\' + (Get-Date -Format 'yyyyMMdd-HHmmss-ffff'))
New-Item -ItemType Directory -Path $BackupDir -Force | Out-Null
$Prior = @()
foreach ($Target in $Targets) {
    $RegistryExists = Test-Path -LiteralPath $Target.RegistryPath
    $PreviousDefault = $null
    $PreviousKind = $null
    if ($RegistryExists) {
        $PreviousKey = Get-Item -LiteralPath $Target.RegistryPath
        if ($PreviousKey.GetValueNames() -contains '') {
            $PreviousDefault = $PreviousKey.GetValue('', $null, [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            $PreviousKind = [string]$PreviousKey.GetValueKind('')
        }
    }
    $ManifestExists = Test-Path -LiteralPath $Target.ManifestPath -PathType Leaf
    if ($ManifestExists) { Copy-Item -LiteralPath $Target.ManifestPath -Destination $BackupDir }
    $Prior += [pscustomobject]@{
        Browser = $Target.Browser
        RegistryPath = $Target.RegistryPath
        RegistryExists = $RegistryExists
        PreviousDefault = $PreviousDefault
        PreviousKind = $PreviousKind
        ManifestPath = $Target.ManifestPath
        ManifestExists = $ManifestExists
    }
}
$HadHost = Test-Path -LiteralPath $HostExe -PathType Leaf
if ($HadHost) { Copy-Item -LiteralPath $HostExe -Destination (Join-Path $BackupDir 'NolTicketNativeHost.exe') }
[IO.File]::WriteAllText((Join-Path $BackupDir 'registration-before.json'), (ConvertTo-Json -InputObject $Prior -Depth 5), $Utf8NoBom)

try {
    Move-Item -LiteralPath $BuildExe -Destination $HostExe -Force
    foreach ($Target in $Targets) {
        $Manifest = [ordered]@{
            name = $HostName
            description = 'NOL Ticket Assistant: local opt-in macro start bridge'
            path = $HostExe
            type = 'stdio'
            allowed_origins = @('chrome-extension://' + $Target.Id + '/')
        }
        [IO.File]::WriteAllText($Target.ManifestPath, ($Manifest | ConvertTo-Json -Depth 4), $Utf8NoBom)
        New-Item -Path $Target.RegistryPath -Force | Out-Null
        Set-Item -LiteralPath $Target.RegistryPath -Value $Target.ManifestPath
        Write-Host ('Registered ' + $Target.Browser + ' for extension ' + $Target.Id)
    }
}
catch {
    $InstallError = $_
    # Restore the exact default values we changed; preserve other registry values.
    foreach ($Entry in $Prior) {
        try {
            if ($Entry.RegistryExists) {
                New-Item -Path $Entry.RegistryPath -Force | Out-Null
                if ($null -eq $Entry.PreviousKind) { (Get-Item -LiteralPath $Entry.RegistryPath).DeleteValue('', $false) }
                else { (Get-Item -LiteralPath $Entry.RegistryPath).SetValue('', $Entry.PreviousDefault, [Microsoft.Win32.RegistryValueKind]$Entry.PreviousKind) }
            }
            elseif (Test-Path -LiteralPath $Entry.RegistryPath) { Remove-Item -LiteralPath $Entry.RegistryPath }
            if ($Entry.ManifestExists) { Copy-Item -LiteralPath (Join-Path $BackupDir ([IO.Path]::GetFileName($Entry.ManifestPath))) -Destination $Entry.ManifestPath -Force }
            elseif (Test-Path -LiteralPath $Entry.ManifestPath) { Remove-Item -LiteralPath $Entry.ManifestPath }
        }
        catch { Write-Warning ('Could not restore ' + $Entry.Browser + '; see backup: ' + $BackupDir) }
    }
    try {
        if ($HadHost) { Copy-Item -LiteralPath (Join-Path $BackupDir 'NolTicketNativeHost.exe') -Destination $HostExe -Force }
        elseif (Test-Path -LiteralPath $HostExe) { Remove-Item -LiteralPath $HostExe }
    }
    catch { Write-Warning ('Could not restore the executable; see backup: ' + $BackupDir) }
    throw $InstallError
}
finally {
    if (Test-Path -LiteralPath $BuildExe) { Remove-Item -LiteralPath $BuildExe }
}
Write-Host ('Installed. Keep this directory in place: ' + $BridgeRoot)
Write-Host ('Prior settings saved in: ' + $BackupDir)
Write-Host 'Start EnhancedMacro.ahk, opt in to browser start, then run the extension connection check.'
