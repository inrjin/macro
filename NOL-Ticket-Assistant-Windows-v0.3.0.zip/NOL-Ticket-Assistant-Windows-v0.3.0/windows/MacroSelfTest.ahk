﻿; Runs without pointer/keyboard input. Hidden GUI exists only for validating settings.
RunSelfTest() {
    global Bound, Steps
    try {
        TestAssert(ColorMatches(0x123456, 0x123456, 0), "exact pixel color")
        TestAssert(!ColorMatches(0x123457, 0x123456, 0), "color mismatch")
        TestAssert(ColorMatches(0x123457, 0x123456, 1), "color tolerance")
        TestAssert(!ValidInt("-1", 0, 100), "negative coordinates rejected")
        TestAssert(ValidColor("0x112233"), "BGR color")
        TestAssert(!ValidColor("0x11223344"), "oversized color rejected")
        Bound := {width:1280, height:720}
        step := {name:"test", x:200, y:300, enabled:1, delay:500, timeout:2000, wait:0}
        TestAssert(ValidateStep(step, reason, true), "valid step")
        step.timeout := 500
        TestAssert(!ValidateStep(step, reason, true), "timeout must exceed delay")
        step.timeout := 2000, step.x := 1280
        TestAssert(!ValidateStep(step, reason, true), "out-of-bounds step rejected")
        rects := []
        AddRect(rects, 3, 4, 2, 5)
        TestAssert(rects.Length() = 0, "inverted rectangles rejected")
        AddRect(rects, 0, 0, 10, 10)
        TestAssert(rects.Length() = 1, "valid rectangle")
        FileAppend, PASS: 11 macro self-tests. No browser input sent.`n, *
        ExitApp, 0
    } catch e {
        FileAppend, % "FAIL: " e.Message "`n", *
        ExitApp, 1
    }
}
TestAssert(condition, label) {
    if (!condition)
        throw Exception(label)
}
